# Parking Garage System

A check-in / check-out system for a multi-level parking garage: correct
tiered billing, spot-type aware allocation (compact / standard / EV),
instant "is a spot free?" and "where's my car?" lookups, and a guarantee
that no spot is ever double-parked.

Built generically — the number of levels, spots per type, and rates all
come from a config file, so this works for **any** garage, not one.

## How the spec maps to the code

| Requirement | Where it's handled |
|---|---|
| Tiered pricing, part-hour rounds up, daily cap | `garage/pricing.py` (`PricingEngine`) |
| Spot types incl. EV-must-get-EV-spot | `garage/spot_manager.py` (`SpotManager`, `DEFAULT_FALLBACK_ORDER`) |
| Never double-park a spot | `SpotManager.occupy_spot` — checks `is_occupied` before assigning, raises `SpotAlreadyOccupiedError` otherwise. `Garage.check_in` also checks availability *before* opening a ticket, so a failed check-in never leaves a dangling ticket. |
| "Is an EV spot free right now?" | `Garage.is_spot_type_available()` — O(1), backed by a free-id `set` per spot type |
| Find a car by plate | `Garage.find_car()` — O(1) dict lookup in `TicketManager` |
| Log gets huge by evening | Active tickets live in a small dict (`_active_by_plate`); closed tickets go to an append-only `_history` list, kept separate so the hot "is this car here?" path never scans the whole day's log |
| Works for any garage | `Garage.from_config()` reads levels / spot counts / rates from `data/config.json` |

### Pricing rule, precisely
- First billable hour → `first_hour` rate.
- Every additional billable hour → cheaper `additional_hour` rate.
- Any part of an hour counts as a full hour (`ceil`), minimum 1 hour billed.
- The fee for any 24h window is capped at `daily_cap`.
- Stays over 24h: `full_days * daily_cap + capped_fee(remaining_hours)` — so a
  multi-day stay is billed as a stack of capped days, never an unbounded number.

### Spot allocation rule
- EV vehicle → **only** an EV spot (it needs the charger). No fallback — if
  no EV spot is free, check-in fails with `GarageFullError`.
- Compact vehicle → compact spot preferred, falls back to a standard spot if
  compact is full (a small car fits a bigger space).
- Standard vehicle → standard spot only.

This fallback table (`DEFAULT_FALLBACK_ORDER` in `spot_manager.py`) is just
data, so you can change the rules (e.g. make it stricter) in one place.

## Project structure
```
parking-garage/
├── garage/
│   ├── models.py         # Spot, Vehicle, Ticket, enums (dumb data holders)
│   ├── pricing.py         # RateCard + PricingEngine (fee math)
│   ├── spot_manager.py     # spot allocation / availability, O(1) lookups
│   ├── ticket_manager.py   # check-in/out lifecycle, O(1) plate lookup
│   ├── garage.py           # public facade (`Garage`) wiring it together
│   └── exceptions.py
├── data/
│   └── config.json         # garage layout + rates (edit this for a new garage)
├── cli.py                  # interactive attendant console
├── tests/                  # pytest suite (27 tests)
└── requirements.txt
```

## Setup in GitHub Codespaces

1. Push this folder to a new GitHub repo (or create the repo and add these
   files directly), then click **Code → Codespaces → Create codespace on
   main**. Codespaces gives you Python 3 pre-installed, so nothing extra to
   configure.

2. Once the codespace opens, in its terminal:

```bash
# (optional but recommended) isolate dependencies
python3 -m venv .venv
source .venv/bin/activate

# install dependencies
pip install -r requirements.txt
```

3. Run the tests to confirm everything works:

```bash
python -m pytest -v
```
You should see `27 passed`.

4. Run the interactive attendant console:

```bash
python cli.py
```

Example session:
```
attendant> checkin DL1AB1234 compact
  OK  ticket=T000001 spot=L1-COMPACT-001 plate=DL1AB1234
attendant> available ev
  ev: YES (5 free)
attendant> status dl1ab1234
  DL1AB1234: spot=L1-COMPACT-001 entry=2026-09-17 09:00:00 type=compact
attendant> checkout DL1AB1234
  OK  ticket=T000001 duration=125.0 min fee=Rs.50.00
attendant> summary
  compact   : 10 free
  standard  : 15 free
  ev        : 5 free
attendant> exit
```

To point at a different garage layout/rates:
```bash
python cli.py --config data/config.json
```
(swap in your own JSON file with the same shape — see `data/config.json`).

## Using it as a library (e.g. to build a UI/API on top)
```python
from datetime import datetime
from garage.garage import Garage
from garage.models import VehicleType

g = Garage.from_config("data/config.json")

result = g.check_in("DL1AB1234", VehicleType.COMPACT)
print(result.ticket.ticket_id, result.spot.spot_id)

g.is_spot_type_available(SpotType.EV)   # -> bool
g.find_car("DL1AB1234")                 # -> Ticket or None

out = g.check_out("DL1AB1234")
print(out.fee, out.duration_minutes)
```

## Git commands to get this into a repo (run from this folder)
```bash
git init
git add .
git commit -m "Parking garage attendant system"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```
Then open Codespaces on that repo as described above.

## Scaling notes (why it stays fast as the log grows)
- **Plate lookup / EV availability** are both O(1): a dict keyed by plate for
  active tickets, and a `set` of free spot ids per spot type. Neither scans
  the full day's log.
- **Closed tickets** accumulate in memory for the day (`Garage.history()`).
  For a real deployment, swap the in-memory `_history` list in
  `ticket_manager.py` for an append to a database/log file at `close_ticket`
  time, so RAM use doesn't grow with the day's total car count — the O(1)
  active-ticket path is unaffected either way.

## Possible next steps
- Persist state (SQLite) so the garage survives a restart mid-day.
- REST API wrapper (FastAPI/Flask) around `Garage` for a real attendant app.
- Reservation/pre-booking of a spot.
- Multiple rate cards by time-of-day (peak/off-peak).
